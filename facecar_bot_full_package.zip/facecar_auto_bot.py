
import logging
import random
import asyncio
from aiogram import Bot, Dispatcher, types

API_TOKEN = '7793197682:AAGmHaK93e4ARcCV2XZ494zwUlVXESawOP0'
CHANNEL_ID = '@face_car19'

from facecar_phrases import STARTERS, MIDDLES, ENDINGS

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

def generate_caption():
    return "{}\n{}\n{}".format(
        random.choice(STARTERS),
        random.choice(MIDDLES),
        random.choice(ENDINGS)
    )

async def send_daily_post():
    while True:
        text = generate_caption()
        try:
            await bot.send_message(CHANNEL_ID, text)
        except Exception as e:
            logging.error(f"Ошибка при отправке: {e}")
        await asyncio.sleep(86400)  # 1 раз в сутки

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply("Бот запущен. Посты будут лететь в канал ежедневно.")

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.create_task(send_daily_post())
    from aiogram import executor
    executor.start_polling(dp, skip_updates=True)
